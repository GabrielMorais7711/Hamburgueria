<?php

include "banco.php";

// Busca todos os produtos
$sql = "SELECT * FROM produtos ORDER BY categoria, nome";
$result = $conn->query($sql);

$produtos = [];
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $produtos[] = $row;
    }
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mc Ronald's - Cardápio</title>
    <link rel="stylesheet" href="assets/style.css">
    <link rel="stylesheet" href="assets/cardapio.css">
</head>
<body>

<section class="cardapio">

    <header>
        <a href="index.php"><img src="assets/imgs/logo.png" class="logo"></a>
        <ul>
            <li><a href="index.php">Início</a></li>
            <li><a href="cardapio.php" class="active">Cardápio</a></li>
        </ul>
    </header>

    <div class="content-cardapio">
        <div class="textBox-cardapio">
            <h2>Confira o nosso<br><span>Cardápio</span></h2>
            <p>Escolha sua categoria e descubra os melhores sabores do McRonald’s!</p>
        </div>
    </div>

    <div class="menu-categorias">
        <button class="categoria active" data-cat="lanches">Lanches</button>
        <button class="categoria" data-cat="bebidas">Bebidas</button>
        <button class="categoria" data-cat="sobremesas">Sobremesas</button>
        <button class="categoria" data-cat="entradas">Entradas</button>
    </div>

    <div class="container">
        <?php foreach ($produtos as $p): ?>
            <div class="produto" data-cat="<?= htmlspecialchars($p['categoria']) ?>">
                <img src="<?= htmlspecialchars($p['imagem']) ?>" alt="<?= htmlspecialchars($p['nome']) ?>">
                <h2><?= htmlspecialchars($p['nome']) ?></h2>
                <p>R$ <?= number_format($p['preco'], 2, ',', '.') ?></p>
            </div>
        <?php endforeach; ?>
    </div>
</section>

<script>
const botoes = document.querySelectorAll(".categoria");
const produtos = document.querySelectorAll(".produto");

botoes.forEach(btn => {
    btn.addEventListener("click", () => {
        botoes.forEach(b => b.classList.remove("active"));
        btn.classList.add("active");

        const categoria = btn.dataset.cat;
        produtos.forEach(prod => {
            prod.style.display = prod.dataset.cat === categoria ? "block" : "none";
        });
    });
});

window.addEventListener("DOMContentLoaded", () => {
    produtos.forEach(prod => {
        prod.style.display = prod.dataset.cat === "lanches" ? "block" : "none";
    });
});
</script>

</body>
</html>
