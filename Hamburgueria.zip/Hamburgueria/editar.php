<?php
include 'banco.php';

// ==========================
// 1. Verificar se o ID do pedido foi informado
// ==========================
if (!isset($_GET['id'])) {
    echo "<script>window.location='pedido.php';</script>";
    exit;
}

$idPedido = (int)$_GET['id'];

// ==========================
// 2. Buscar dados do pedido e itens
// ==========================
$sqlPedido = "SELECT * FROM pedidos WHERE idPedido = $idPedido";
$resPedido = $conn->query($sqlPedido);

if ($resPedido->num_rows == 0) {
    echo "<script>alert('Pedido não encontrado.'); window.location='pedido.php';</script>";
    exit;
}

$pedido = $resPedido->fetch_assoc();

// Buscar os itens do pedido
$sqlItens = "
    SELECT it.idProduto, it.qtd, pr.nome, pr.preco, pr.categoria, pr.imagem
    FROM itens_pedido it
    JOIN produtos pr ON it.idProduto = pr.idProduto
    WHERE it.idPedido = $idPedido
";
$resItens = $conn->query($sqlItens);
$itensPedido = [];
while ($row = $resItens->fetch_assoc()) {
    $itensPedido[strtolower($row['categoria'])] = $row;
}

// ==========================
// 3. Buscar lista de produtos por categoria
// ==========================
$resProdutos = $conn->query("SELECT * FROM produtos ORDER BY categoria, nome");
$produtos = [];
while ($row = $resProdutos->fetch_assoc()) {
    $produtos[strtolower($row['categoria'])][] = $row;
}

// ==========================
// 4. Atualizar o pedido (se enviado)
// ==========================
if (isset($_POST['salvar'])) {
    $nomePessoa = $conn->real_escape_string($_POST['nomePessoa']);
    $adicionais = $conn->real_escape_string($_POST['adicionais']);
    $formaPgto = $conn->real_escape_string($_POST['formaPgto']);

    // Atualiza informações básicas do pedido
    $conn->query("
        UPDATE pedidos 
        SET nomePessoa = '$nomePessoa', adicionais = '$adicionais', formaPgto = '$formaPgto'
        WHERE idPedido = $idPedido
    ");

    // Remove os itens antigos
    $conn->query("DELETE FROM itens_pedido WHERE idPedido = $idPedido");

    // Reinsere os itens com base na seleção atual
    $categorias = ['lanches', 'bebidas', 'sobremesas', 'entradas'];
    $temProduto = false;

    foreach ($categorias as $cat) {
        if (isset($_POST[$cat]['produto']) && (int)$_POST[$cat]['produto'] > 0) {
            $idProduto = (int)$_POST[$cat]['produto'];
            $qtd = max(1, (int)$_POST[$cat]['qtd']);

            $resPreco = $conn->query("SELECT preco FROM produtos WHERE idProduto = $idProduto");
            if ($resPreco && $resPreco->num_rows > 0) {
                $preco = $resPreco->fetch_assoc()['preco'];
                $valorTotal = $preco * $qtd;
                $conn->query("INSERT INTO itens_pedido (idPedido, idProduto, qtd, valorTotal) VALUES ($idPedido, $idProduto, $qtd, $valorTotal)");
                $temProduto = true;
            }
        }
    }

    if (!$temProduto) {
        echo "<script>alert('Você deve deixar pelo menos um produto selecionado.'); history.back();</script>";
        exit;
    }

    echo "<script>alert('Pedido atualizado com sucesso!'); window.location='pedido.php';</script>";
    exit;
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta charset="UTF-8">
<title>Editar Pedido 🍔</title>
<link rel="stylesheet" href="assets/pedido.css">
<style>
    .categoria-bloco {
        margin-bottom: 15px;
        background: #f7f7f7;
        padding: 10px;
        border-radius: 8px;
        position: relative;
    }
    .preview-img {
        display: none;
        position: absolute;
        width: 120px;
        height: 120px;
        object-fit: cover;
        border-radius: 8px;
        box-shadow: 0 0 5px rgba(0,0,0,0.3);
        background: #fff;
        z-index: 10;
    }
</style>
<script>
document.addEventListener("DOMContentLoaded", () => {
    const preview = document.createElement('img');
    preview.className = 'preview-img';
    document.body.appendChild(preview);

    document.querySelectorAll('option[data-img]').forEach(opt => {
        opt.addEventListener('mouseenter', e => {
            preview.src = opt.getAttribute('data-img');
            preview.style.display = 'block';
        });
        opt.addEventListener('mousemove', e => {
            preview.style.left = e.pageX + 15 + 'px';
            preview.style.top = e.pageY + 15 + 'px';
        });
        opt.addEventListener('mouseleave', () => preview.style.display = 'none');
    });
});
</script>
</head>
<body>
<div class="container">
    <div class="form-box">
        <h2>Editar Pedido de <?= htmlspecialchars($pedido['nomePessoa']) ?></h2>
        <form method="POST" action="">
            <label>Nome:</label>
            <input type="text" name="nomePessoa" value="<?= htmlspecialchars($pedido['nomePessoa']) ?>" required>

            <?php
            $categoriasNomes = [
                'lanches' => '🍔 Lanches',
                'bebidas' => '🥤 Bebidas',
                'sobremesas' => '🍨 Sobremesas',
                'entradas' => '🍟 Entradas'
            ];

            foreach ($categoriasNomes as $key => $label):
                $idAtual = $itensPedido[$key]['idProduto'] ?? 0;
                $qtdAtual = $itensPedido[$key]['qtd'] ?? 1;
            ?>
                <div class="categoria-bloco">
                    <label><?= $label ?>:</label>
                    <select name="<?= $key ?>[produto]">
                        <option value="0"> Nenhum </option>
                        <?php if (!empty($produtos[$key])): ?>
                            <?php foreach ($produtos[$key] as $p): ?>
                                <option 
                                    value="<?= $p['idProduto'] ?>" 
                                    data-img="<?= htmlspecialchars($p['imagem']) ?>"
                                    <?= $p['idProduto'] == $idAtual ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($p['nome']) ?> - R$ <?= number_format($p['preco'], 2, ',', '.') ?>
                                </option>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </select>

                    <label>Quantidade:</label>
                    <input type="number" name="<?= $key ?>[qtd]" value="<?= $qtdAtual ?>" min="1">
                </div>
            <?php endforeach; ?>

            <label>Adicionais:</label>
            <input type="text" name="adicionais" value="<?= htmlspecialchars($pedido['adicionais']) ?>">

            <label>Forma de pagamento:</label>
            <select name="formaPgto" required>
                <option value="Dinheiro" <?= $pedido['formaPgto']=='Dinheiro'?'selected':'' ?>>Dinheiro</option>
                <option value="Cartão" <?= $pedido['formaPgto']=='Cartão'?'selected':'' ?>>Cartão</option>
                <option value="Pix" <?= $pedido['formaPgto']=='Pix'?'selected':'' ?>>Pix</option>
            </select>

            <button type="submit" name="salvar">Salvar Alterações</button>
        </form>
    </div>
</div>
</body>
</html>
