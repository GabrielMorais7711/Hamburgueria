<?php
include 'banco.php';
$id = (int)$_GET['id'];
$res = $conn->query("SELECT nomePessoa, formaPgto, adicionais FROM pedidos WHERE idPedido = $id");
if ($res && $res->num_rows > 0) {
    $row = $res->fetch_assoc();
    $nome = $conn->real_escape_string($row['nomePessoa']);
    $forma = $conn->real_escape_string($row['formaPgto']);
    $ad = $conn->real_escape_string($row['adicionais']);
    $conn->query("DELETE FROM pedidos WHERE nomePessoa='$nome' AND formaPgto='$forma' AND adicionais='$ad'");
}
header("Location: pedido.php");
exit;
?>
