<?php
include 'banco.php';

// Verifica se o ID foi informado
if (!isset($_GET['id'])) {
    header("Location: pedido.php");
    exit;
}

$idPedido = (int)$_GET['id'];

// Verifica se o pedido existe
$res = $conn->query("SELECT * FROM pedidos WHERE idPedido = $idPedido");
if ($res && $res->num_rows > 0) {
    // Exclui os itens do pedido primeiro (respeitando integridade)
    $conn->query("DELETE FROM itens_pedido WHERE idPedido = $idPedido");
    
    // Depois exclui o pedido em si
    $conn->query("DELETE FROM pedidos WHERE idPedido = $idPedido");
    
    echo "<script>alert('Pedido excluído com sucesso!'); window.location='pedido.php';</script>";
    exit;
} else {
    echo "<script>alert('Pedido não encontrado.'); window.location='pedido.php';</script>";
    exit;
}
?>
