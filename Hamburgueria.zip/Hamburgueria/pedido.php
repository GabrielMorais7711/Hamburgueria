<?php
include 'banco.php';

// ==========================
// 1. Buscar produtos
// ==========================
$res = $conn->query("SELECT idProduto, nome, preco, categoria, imagem FROM produtos ORDER BY categoria, nome");
$produtos = [];
while ($row = $res->fetch_assoc()) {
    $categoria = strtolower($row['categoria']);
    $produtos[$categoria][] = $row;
}

// ==========================
// 2. Inserir pedido e itens
// ==========================
if (isset($_POST['enviar'])) {
    $nomePessoa = trim($_POST['nomePessoa']);
    $adicionais = trim($_POST['adicionais']);
    $formaPgto = $_POST['formaPgto'];

    if (empty($nomePessoa)) {
        echo "<script>alert('Informe o nome.'); history.back();</script>";
        exit;
    }

    $conn->query("INSERT INTO pedidos (nomePessoa, adicionais, formaPgto) VALUES (
        '{$conn->real_escape_string($nomePessoa)}',
        '{$conn->real_escape_string($adicionais)}',
        '{$conn->real_escape_string($formaPgto)}'
    )");

    $idPedido = $conn->insert_id;
    $categorias = ['lanches', 'bebidas', 'sobremesas', 'entradas'];
    $temProduto = false;

    foreach ($categorias as $cat) {
        if (isset($_POST[$cat]['produto']) && (int)$_POST[$cat]['produto'] > 0) {
            $idProduto = (int)$_POST[$cat]['produto'];
            $qtd = max(1, (int)$_POST[$cat]['qtd']);

            $resPreco = $conn->query("SELECT preco FROM produtos WHERE idProduto = $idProduto");
            if ($resPreco && $resPreco->num_rows > 0) {
                $preco = $resPreco->fetch_assoc()['preco'];
                $valorTotal = $preco * $qtd;
                $conn->query("INSERT INTO itens_pedido (idPedido, idProduto, qtd, valorTotal) VALUES ($idPedido, $idProduto, $qtd, $valorTotal)");
                $temProduto = true;
            }
        }
    }

    if (!$temProduto) {
        $conn->query("DELETE FROM pedidos WHERE idPedido = $idPedido");
        echo "<script>alert('Você deve selecionar pelo menos um produto.'); history.back();</script>";
        exit;
    }

    echo "<script>alert('Pedido realizado com sucesso!'); window.location='pedido.php';</script>";
    exit;
}

// ==========================
// 3. Estatísticas e filtros
// ==========================
$filtroProduto = isset($_GET['filtroProduto']) ? (int)$_GET['filtroProduto'] : 0;
$filtroValor = isset($_GET['filtroValor']) ? (float)$_GET['filtroValor'] : 0;

$resMaisVendido = $conn->query("
    SELECT pr.nome, SUM(it.qtd) AS totalVendido
    FROM itens_pedido it
    JOIN produtos pr ON it.idProduto = pr.idProduto
    GROUP BY it.idProduto
    ORDER BY totalVendido DESC
    LIMIT 1
");
$maisVendido = $resMaisVendido->fetch_assoc();

$resFaturamento = $conn->query("SELECT SUM(valorTotal) AS totalFaturamento FROM itens_pedido");
$faturamento = $resFaturamento->fetch_assoc()['totalFaturamento'];
?>


<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Monte seu Pedido 🍔</title>
    <link rel="stylesheet" type="text/css" href="assets/pedido.css">
    <link rel="stylesheet" type="text/css" href="assets/style.css">
    <style>
        .categoria-bloco {
            margin-bottom: 15px;
            background: #f7f7f7;
            padding: 10px;
            border-radius: 8px;
            position: relative;
        }
        .imagem-preview {
            position: absolute;
            right: -180px;
            top: 10px;
            width: 160px;
            height: 120px;
            object-fit: cover;
            border-radius: 8px;
            display: none;
            box-shadow: 0 0 6px rgba(0,0,0,0.3);
            background: #fff;
        }
        .pedido-item {
            background: #fff;
            padding: 10px;
            margin-bottom: 8px;
            border-radius: 8px;
            box-shadow: 0 0 4px rgba(0,0,0,0.1);
        }
        .stats {
            background: #e7f7e7;
            padding: 10px;
            border-radius: 8px;
            margin-top: 15px;
        }
    </style>
</head>
<body>

<header>
    <a href="index.php"><img src="assets/imgs/logo.png" class="logo"></a>
</header>

<div class="container">
    <div class="form-box">
        <h2>Monte seu pedido 🍔</h2>
        <form method="POST" action="">
            <label>Nome:</label>
            <input type="text" name="nomePessoa" required>

            <?php
            $categorias = [
                'lanches' => '🍔 Lanches',
                'bebidas' => '🥤 Bebidas',
                'sobremesas' => '🍨 Sobremesas',
                'entradas' => '🍟 Entradas'
            ];

            foreach ($categorias as $key => $label):
            ?>
                <div class="categoria-bloco">
                    <label><?= $label ?>:</label>
                    <select name="<?= $key ?>[produto]" class="select-produto" data-preview-id="preview-<?= $key ?>">
                        <option value="0" data-img="">Nenhum</option>
                        <?php if (!empty($produtos[$key])): ?>
                            <?php foreach ($produtos[$key] as $p): ?>
                                <option value="<?= $p['idProduto'] ?>" data-img="<?= htmlspecialchars($p['imagem']) ?>">
                                    <?= $p['nome'] ?> - R$ <?= number_format($p['preco'], 2, ',', '.') ?>
                                </option>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </select>
                    <img id="preview-<?= $key ?>" class="imagem-preview" src="" alt="Prévia do produto">

                    <label>Quantidade:</label>
                    <input type="number" name="<?= $key ?>[qtd]" value="1" min="1">
                </div>
            <?php endforeach; ?>

            <label>Adicionais (opcional):</label>
            <input type="text" name="adicionais">

            <label>Forma de pagamento:</label>
            <select name="formaPgto" required>
                <option value="Dinheiro">Dinheiro</option>
                <option value="Cartão">Cartão</option>
                <option value="Pix">Pix</option>
            </select>

            <button type="submit" name="enviar">Enviar Pedido</button>
        </form>
    </div>

    <div class="form-box">
        <h2>Filtrar Pedidos</h2>
        <form method="GET" action="">
            <label>Filtrar por Produto:</label>
            <select name="filtroProduto">
                <option value="0">Todos</option>
                <?php
                foreach ($produtos as $categoria => $lista) {
                    foreach ($lista as $p) {
                        $selected = ($filtroProduto == $p['idProduto']) ? 'selected' : '';
                        echo "<option value='{$p['idProduto']}' $selected>{$p['nome']}</option>";
                    }
                }
                ?>
            </select>

            <label>Filtrar por Valor mínimo:</label>
            <input type="number" name="filtroValor" step="0.01" value="<?= $filtroValor ?>">

            <button type="submit">Filtrar</button>
        </form>
    </div>

    <div class="stats">
        <h3>Estatísticas</h3>
        <p>Produto mais vendido: <strong><?= $maisVendido['nome'] ?? 'Nenhum' ?></strong> (<?= $maisVendido['totalVendido'] ?? 0 ?> unidades)</p>
        <p>Faturamento total: <strong>R$ <?= number_format($faturamento ?? 0, 2, ',', '.') ?></strong></p>
    </div>

    <div class="pedidos">
        <h2>Pedidos cadastrados</h2>
        <?php
        $sql = "SELECT 
                    p.idPedido,
                    p.nomePessoa,
                    p.adicionais,
                    p.formaPgto,
                    GROUP_CONCAT(CONCAT(pr.nome, ' (', it.qtd, ')') SEPARATOR ', ') AS produtos,
                    SUM(it.valorTotal) AS total
                FROM pedidos p
                JOIN itens_pedido it ON p.idPedido = it.idPedido
                JOIN produtos pr ON it.idProduto = pr.idProduto
                WHERE 1=1";

        if ($filtroProduto > 0) $sql .= " AND it.idProduto = $filtroProduto";
        if ($filtroValor > 0) $sql .= " AND it.valorTotal >= $filtroValor";

        $sql .= " GROUP BY p.idPedido ORDER BY p.idPedido DESC";

        $res = $conn->query($sql);
        if ($res->num_rows > 0) {
            while ($row = $res->fetch_assoc()) {
                echo "<div class='pedido-item'>";
                echo "<strong>" . htmlspecialchars($row['nomePessoa']) . "</strong><br>";
                echo "Produtos: " . htmlspecialchars($row['produtos']) . "<br>";
                echo "Total: R$ " . number_format($row['total'], 2, ',', '.') . "<br>";
                echo "Pagamento: " . htmlspecialchars($row['formaPgto']) . "<br>";
                if (!empty($row['adicionais'])) echo "Adicionais: " . htmlspecialchars($row['adicionais']) . "<br>";
                echo "<a href='editar.php?id=" . $row['idPedido'] . "'>Atualizar</a> | ";
                echo "<a href='excluir.php?id=" . $row['idPedido'] . "' onclick=\"return confirm('Deseja realmente excluir este pedido?')\">Excluir</a>";
                echo "</div><hr>";
            }
        } else {
            echo "<p>Nenhum pedido encontrado.</p>";
        }
        ?>

    </div>
</div>

<script>
// Mostra a imagem ao passar o mouse
document.querySelectorAll('.select-produto').forEach(select => {
    const preview = document.getElementById(select.dataset.previewId);
    select.addEventListener('mouseover', () => {
        const img = select.options[select.selectedIndex].dataset.img;
        if (img) {
            preview.src = img;
            preview.style.display = 'block';
        }
    });
    select.addEventListener('mouseout', () => {
        preview.style.display = 'none';
    });
    select.addEventListener('change', () => {
        const img = select.options[select.selectedIndex].dataset.img;
        preview.src = img;
    });
});
</script>
</body>
</html>
