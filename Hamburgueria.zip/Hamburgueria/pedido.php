<?php
include 'banco.php';

$res = $conn->query("SELECT idProduto, nome, preco, categoria FROM produtos ORDER BY categoria, nome");
$produtos = [];
while ($row = $res->fetch_assoc()) {
    $categoria = strtolower($row['categoria']);
    $produtos[$categoria][] = $row;
}

if (isset($_POST['enviar'])) {
    $nomePessoa = $_POST['nomePessoa'];
    $qtd = (int)$_POST['qtd'];
    $adicionais = $_POST['adicionais'];
    $formaPgto = $_POST['formaPgto'];

    $prodSelecionados = [
        'lanches' => (int)$_POST['lanches'],
        'bebidas' => (int)$_POST['bebidas'],
        'sobremesas' => (int)$_POST['sobremesas'],
        'entradas' => (int)$_POST['entradas']
    ];

    if (!array_filter($prodSelecionados)) {
        echo "<script>alert('Você deve selecionar pelo menos um produto.'); history.back();</script>";
        exit;
    }

    $nomeEsc = $conn->real_escape_string($nomePessoa);
    $adicionaisEsc = $conn->real_escape_string($adicionais);
    $formaPgtoEsc = $conn->real_escape_string($formaPgto);

    foreach ($prodSelecionados as $categoria => $produto) {
        if ($produto > 0) {
            $resPreco = $conn->query("SELECT preco FROM produtos WHERE idProduto = $produto");
            if ($resPreco && $resPreco->num_rows > 0) {
                $row = $resPreco->fetch_assoc();
                $preco = $row['preco'];
                $valorTotal = $preco * $qtd;

                $sql = "INSERT INTO pedidos (idProduto, qtd, valorTotal, nomePessoa, adicionais, formaPgto)
                        VALUES ($produto, $qtd, $valorTotal, '$nomeEsc', '$adicionaisEsc', '$formaPgtoEsc')";
                $conn->query($sql);
            }
        }
    }

    echo "<script>alert('Pedido realizado com sucesso!'); window.location='pedido.php';</script>";
    exit;
}

$filtroProduto = isset($_GET['filtroProduto']) ? (int)$_GET['filtroProduto'] : 0;
$filtroValor = isset($_GET['filtroValor']) ? (float)$_GET['filtroValor'] : 0;

$resMaisVendido = $conn->query("
    SELECT pr.nome, SUM(p.qtd) AS totalVendido
    FROM pedidos p
    JOIN produtos pr ON p.idProduto = pr.idProduto
    GROUP BY p.idProduto
    ORDER BY totalVendido DESC
    LIMIT 1
");
$maisVendido = $resMaisVendido->fetch_assoc();

$resFaturamento = $conn->query("SELECT SUM(valorTotal) AS totalFaturamento FROM pedidos");
$faturamento = $resFaturamento->fetch_assoc()['totalFaturamento'];
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Monte seu Pedido 🍔</title>
    </head>
    <link rel="stylesheet" type="text/css" href="assets/pedido.css">
<body>
    <div class="container">
        <div class="form-box">
            <h2>Monte seu pedido 🍔</h2>
            <form method="POST" action="">
                <label>Nome:</label>
                <input type="text" name="nomePessoa" required>
                <?php
                $categorias = ['lanches' => '🍔 Lanches', 'bebidas' => '🥤 Bebidas', 'sobremesas' => '🍨 Sobremesas', 'entradas' => '🍟 Entradas'];
                foreach ($categorias as $key => $label):
                ?>
                    <label><?= $label ?> (opcional):</label>
                    <select name="<?= $key ?>">
                        <option value="0"> Nenhum </option>
                        <?php if(!empty($produtos[$key])): ?>
                            <?php foreach($produtos[$key] as $p): ?>
                                <option value="<?= $p['idProduto'] ?>"><?= $p['nome'] ?> - R$ <?= number_format($p['preco'],2,',','.') ?></option>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </select>
                <?php endforeach; ?>
                <label>Quantidade:</label>
                <input type="number" name="qtd" value="1" min="1">
                <label>Adicionais (opcional):</label>
                <input type="text" name="adicionais">
                <label>Forma de pagamento:</label>
                <select name="formaPgto" required>
                    <option value="Dinheiro">Dinheiro</option>
                    <option value="Cartão">Cartão</option>
                    <option value="Pix">Pix</option>
                </select>
                <button type="submit" name="enviar">Enviar Pedido</button>
            </form>
        </div>

        <div class="form-box">
            <h2>Filtrar Pedidos</h2>
            <form method="GET" action="">
                <label>Filtrar por Produto:</label>
                <select name="filtroProduto">
                    <option value="0">Todos</option>
                    <?php
                    foreach($produtos as $categoria => $lista) {
                        foreach($lista as $p) {
                            $selected = ($filtroProduto == $p['idProduto']) ? 'selected' : '';
                            echo "<option value='{$p['idProduto']}' $selected>{$p['nome']}</option>";
                        }
                    }
                    ?>
                </select>
                <label>Filtrar por Valor mínimo:</label>
                <input type="number" name="filtroValor" step="0.01" value="<?= $filtroValor ?>">
                <button type="submit">Filtrar</button>
            </form>
        </div>

        <div class="stats">
            <h3>Estatísticas</h3>
            <p>Produto mais vendido: <strong><?= $maisVendido['nome'] ?? 'Nenhum' ?></strong> (<?= $maisVendido['totalVendido'] ?? 0 ?> unidades)</p>
            <p>Faturamento total: <strong>R$ <?= number_format($faturamento ?? 0,2,',','.') ?></strong></p>
        </div>

        <div class="pedidos">
            <h2>Pedidos cadastrados</h2>
            <?php
            $sql = "SELECT MAX(p.idPedido) AS idPedido, p.nomePessoa, p.adicionais, p.formaPgto, 
                           GROUP_CONCAT(CONCAT(pr.nome,' (',p.qtd,')') SEPARATOR ', ') AS produtos,
                           SUM(p.valorTotal) AS total
                    FROM pedidos p
                    JOIN produtos pr ON p.idProduto = pr.idProduto
                    WHERE 1=1";
            if($filtroProduto > 0) $sql .= " AND p.idProduto = $filtroProduto";
            if($filtroValor > 0) $sql .= " AND p.valorTotal >= $filtroValor";
            $sql .= " GROUP BY p.nomePessoa, p.adicionais, p.formaPgto
                      ORDER BY idPedido DESC";
            $res = $conn->query($sql);
            if ($res->num_rows > 0) {
                while ($row = $res->fetch_assoc()) {
                    echo "<div class='pedido-item'>";
                    echo "<strong>".$row['nomePessoa']."</strong><br>";
                    echo "Produtos: ".$row['produtos']."<br>";
                    echo "Total: R$ ".number_format($row['total'],2,',','.')."<br>";
                    echo "Pagamento: ".$row['formaPgto']."<br>";
                    if(!empty($row['adicionais'])) echo "Adicionais: ".$row['adicionais']."<br>";
                    echo "</div>";
                }
            } else {
                echo "<p>Nenhum pedido encontrado.</p>";
            }
            ?>
        </div>
    </div>
</body>
</html>
