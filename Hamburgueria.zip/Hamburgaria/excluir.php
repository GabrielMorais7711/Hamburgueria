<?php
include 'banco.php';

if(isset($_POST['idPedido'])){
    $id = (int)$_POST['idPedido'];

    $res = $conn->query("SELECT nomePessoa, adicionais, formaPgto FROM pedidos WHERE idPedido = $id");
    if($res && $res->num_rows > 0){
        $pedido = $res->fetch_assoc();
        $nome = $conn->real_escape_string($pedido['nomePessoa']);
        $add = $conn->real_escape_string($pedido['adicionais']);
        $pgto = $conn->real_escape_string($pedido['formaPgto']);

        $conn->query("DELETE FROM pedidos WHERE nomePessoa='$nome' AND adicionais='$add' AND formaPgto='$pgto'");
    }

    echo "<script>alert('Pedido excluído com sucesso!'); window.location='pedido.php';</script>";
}
?>
