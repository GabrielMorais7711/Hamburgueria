<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mc Ronald's - Cardápio</title>
    <link rel="stylesheet" href="assets/style.css">
    <link rel="stylesheet" href="assets/cardapio.css">
</head>
<body>

<section class="cardapio">

    <header>
        <a href="index.php"><img src="assets/imgs/logo.png" class="logo"></a>
        <ul>
            <li><a href="index.php">Início</a></li>
            <li><a href="cardapio.php" class="active">Cardápio</a></li>
        </ul>
    </header>

    <div class="content-cardapio">
        <div class="textBox-cardapio">
            <h2>Confira o nosso<br><span>Cardápio</span></h2>
            <p>Escolha sua categoria e descubra os melhores sabores do McRonald’s!</p>
        </div>
    </div>

    <!-- MENU DE CATEGORIAS -->
    <div class="menu-categorias">
        <button class="categoria active" data-cat="lanches">Lanches</button>
        <button class="categoria" data-cat="bebidas">Bebidas</button>
        <button class="categoria" data-cat="sobremesas">Sobremesas</button>
        <button class="categoria" data-cat="entradas">Entradas</button>
    </div>

    <!-- PRODUTOS -->
    <div class="container">
        <!-- LANCHES -->
        <div class="produto" data-cat="lanches">
            <img src="assets/imgs/bigMc.PNG">
            <h2>Big Mac</h2>
            <p>R$ 24,90</p>
        </div>
        <div class="produto" data-cat="lanches">
            <img src="assets/imgs/Mcfrango.PNG" alt="McChicken">
            <h2>McChicken</h2>
            <p>R$ 19,90</p>
        </div>
        <div class="produto" data-cat="lanches">
            <img src="assets/imgs/paiaDemais.PNG" alt="Cheeseburger Duplo">
            <h2>Cheeseburger</h2>
            <p>R$ 22,90</p>
        </div>
        <div class="produto" data-cat="lanches">
            <img src="assets/imgs/DuploMc.PNG" alt="Quarterão com Queijo">
            <h2>Quarterão com Queijo</h2>
            <p>R$ 25,90</p>
        </div>
        <div class="produto" data-cat="lanches">
            <img src="assets/imgs/primeiroMc.PNG">
            <h2>McNífico Bacon</h2>
            <p>R$ 27,90</p>
        </div>
        <div class="produto" data-cat="lanches">
            <img src="assets/imgs/BomDe.PNG" alt="McFish">
            <h2>Tasty Turbo 2 carnes</h2>
            <p>R$ 21,90</p>
        </div>
        <div class="produto" data-cat="lanches">
            <img src="assets/imgs/salve.PNG">
            <h2>Brabo Brabíssimo Frango</h2>
            <p>R$ 29,90</p>
        </div>
        <div class="produto" data-cat="lanches">
            <img src="assets/imgs/Brabo.PNG">
            <h2>Brabo Brabíssimo Carne</h2>
            <p>R$ 26,90</p>
        </div>
        <div class="produto" data-cat="lanches">
            <img src="assets/imgs/Back.PNG">
            <h2>Duplo Burger Bacon</h2>
            <p>R$ 23,90</p>
        </div>
        <div class="produto" data-cat="lanches">
            <img src="assets/imgs/Loud.PNG">
            <h2>Tasty Turbo Bacon 3 carnes</h2>
            <p>R$ 28,90</p>
        </div>
        <div class="produto" data-cat="lanches">
            <img src="assets/imgs/Cuscuiz.PNG">
            <h2>Tasty Turbo Queijo</h2>
            <p>R$ 27,50</p>
        </div>
        <div class="produto" data-cat="lanches">
            <img src="assets/imgs/Leandro.PNG">
            <h2>McCrispy Chicken Bacon Ranch</h2>
            <p>R$ 25,90</p>
        </div>

        <!-- BEBIDAS -->
        <div class="produto" data-cat="bebidas">
            <img src="assets/imgs/refri.PNG">
            <h2>Refrigerante 500ml</h2>
            <p>R$ 8,00</p>
        </div>
        <div class="produto" data-cat="bebidas">
            <img src="assets/imgs/suco.PNG">
            <h2>Suco Natural</h2>
            <p>R$ 10,00</p>
        </div>
        <div class="produto" data-cat="bebidas">
            <img src="assets/imgs/agua.PNG">
            <h2>Água Mineral</h2>
            <p>R$ 5,00</p>
        </div>

        <!-- SOBREMESAS -->
        <div class="produto" data-cat="sobremesas">
            <img src="assets/imgs/sundae.PNG">
            <h2>Sundae Chocolate</h2>
            <p>R$ 12,00</p>
        </div>
        <div class="produto" data-cat="sobremesas">
            <img src="assets/imgs/mcflurry.PNG">
            <h2>McFlurry Oreo</h2>
            <p>R$ 14,90</p>
        </div>
        <div class="produto" data-cat="sobremesas">
            <img src="assets/imgs/torta.PNG">
            <h2>Torta de Maçã</h2>
            <p>R$ 9,90</p>
        </div>

        <!-- ENTRADAS -->
        <div class="produto" data-cat="entradas">
            <img src="assets/imgs/batata.PNG">
            <h2>Batata Frita</h2>
            <p>R$ 11,90</p>
        </div>
        <div class="produto" data-cat="entradas">
            <img src="assets/imgs/nuggets.PNG">
            <h2>McNuggets 6un</h2>
            <p>R$ 13,90</p>
        </div>
        <div class="produto" data-cat="entradas">
            <img src="assets/imgs/fritas.PNG">
            <h2>Batata com Cheddar e Bacon</h2>
            <p>R$ 12,90</p>
        </div>
    </div>
</section>

<script>
// Filtro de categorias
const botoes = document.querySelectorAll(".categoria");
const produtos = document.querySelectorAll(".produto");

botoes.forEach(btn => {
    btn.addEventListener("click", () => {
        botoes.forEach(b => b.classList.remove("active"));
        btn.classList.add("active");

        const categoria = btn.dataset.cat;
        produtos.forEach(prod => {
            prod.style.display = prod.dataset.cat === categoria ? "block" : "none";
        });
    });
});

// Mostrar "Lanches" por padrão
window.addEventListener("DOMContentLoaded", () => {
    produtos.forEach(prod => {
        prod.style.display = prod.dataset.cat === "lanches" ? "block" : "none";
    });
});
</script>

</body>
</html>
