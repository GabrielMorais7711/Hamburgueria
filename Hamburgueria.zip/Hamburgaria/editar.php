<?php
include 'banco.php';

if(isset($_GET['idPedido'])){
    $id = (int)$_GET['idPedido'];
    $res = $conn->query("SELECT * FROM pedidos WHERE idPedido = $id");
    $pedido = $res->fetch_assoc();
} else {
    echo "<script>window.location='pedido.php';</script>";
    exit;
}

if(isset($_POST['editar'])){
    $qtd = (int)$_POST['qtd'];
    $adicionais = $conn->real_escape_string($_POST['adicionais']);
    $formaPgto = $conn->real_escape_string($_POST['formaPgto']);
    $conn->query("UPDATE pedidos SET qtd=$qtd, adicionais='$adicionais', formaPgto='$formaPgto' WHERE idPedido=$id");
    echo "<script>alert('Pedido atualizado!'); window.location='pedido.php';</script>";
}
?>

<form method="POST" action="">
    <h2>Editar Pedido de <?= $pedido['nomePessoa'] ?></h2>
    <label>Quantidade:</label>
    <input type="number" name="qtd" value="<?= $pedido['qtd'] ?>" min="1" required>

    <label>Adicionais:</label>
    <input type="text" name="adicionais" value="<?= $pedido['adicionais'] ?>">

    <label>Forma de pagamento:</label>
    <select name="formaPgto" required>
        <option value="Dinheiro" <?= $pedido['formaPgto']=='Dinheiro'?'selected':'' ?>>Dinheiro</option>
        <option value="Cartão" <?= $pedido['formaPgto']=='Cartão'?'selected':'' ?>>Cartão</option>
        <option value="Pix" <?= $pedido['formaPgto']=='Pix'?'selected':'' ?>>Pix</option>
    </select>

    <button type="submit" name="editar">Salvar Alterações</button>
</form>
