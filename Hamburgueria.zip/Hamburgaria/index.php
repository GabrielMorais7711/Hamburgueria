<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Mc Ronald's</title>

    <link rel="stylesheet" href="assets/style.css">
</head>
<body>
    
    <section>
        <div class="circle"></div>
        <header>
            <a href="#"><img src="assets/imgs/logo.png" class="logo"></a>
            <ul>
                <li><a href="#">Inicio</a></li>
                <li><a href="cardapio.php">Cardápio</a></li>
            </ul>
        </header>
        <div class="content">
            <div class="textBox">
                <h2>não é apenas uma lanchonete!<br>Isso é <span>McRonald's</span></h2>
                <p>Aqui no McRonald’s, o sabor é levado a sério! Nossa missão é transformar cada mordida em uma experiência inesquecível, com lanches preparados na hora, ingredientes selecionados e aquele toque especial que só o McRonald’s tem. Seja para matar a fome no meio do dia, reunir a galera ou curtir um momento em família, temos o combo perfeito pra você.</p>
                <a href="pedido.php">Faça seu pedido</a>
            </div>
            <div class="imgBox">
                <img src="assets/imgs/img1.png" class="mcRonalds">
            </div>
        </div>
        <ul class="thumb">
            <li><img src="assets/imgs/img1.png" onclick="imgSlider('assets/imgs/img1.png');changeCircleColor('#FF0000')"></li>
            <li><img src="assets/imgs/img2.png" onclick="imgSlider('assets/imgs/img2.png');changeCircleColor('#FF4500')"></li>
            <li><img src="assets/imgs/img3.png" onclick="imgSlider('assets/imgs/img3.png');changeCircleColor('#FF8C00')"></li>
        </ul>
        <ul class="sci">
            <li><a href="#"><img src="assets/imgs/facebook.png"></a></li>
            <li><a href="#"><img src="assets/imgs/twitter.png"></a></li>
            <li><a href="#"><img src="assets/imgs/instagram.png"></a></li>
        </ul>
    </section>

    <script type="text/javascript">
        function imgSlider(anything){
            document.querySelector('.mcRonalds').src = anything
        }

        function changeCircleColor(color){
            const circle = document.querySelector('.circle');
            circle.style.background = color;
        }
    </script>

</body>
</html>