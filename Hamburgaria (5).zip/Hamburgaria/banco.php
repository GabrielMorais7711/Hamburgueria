<?php

$bdservidor = '127.0.0.1';
$bdUsuario = 'root';
$bdSenha = '';
$bdBanco = 'hamburgueria';

$conexao = mysqli_connect($bdservidor, $bdUsuario, $bdSenha, $bdBanco);


if (mysqli_connect_errno()) {
    echo "Problemas para conectar no banco. Erro: ";
    echo mysqli_connect_error();
    die();
}