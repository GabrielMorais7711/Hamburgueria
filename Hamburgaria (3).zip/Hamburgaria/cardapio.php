<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>McDonald's - Lanches</title>

    <link rel="stylesheet" href="assets/style.css">
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f9f9f9;
            margin: 0;
            padding: 0;
        }

        header {
            background-color: rgb(181, 24, 24);
            color: white;
            padding: 25px;
            text-align: center;
            position: relative;
        }

        h1 {
            margin: 0;
            font-size: 2.2em;
        }

        /* ===== Submenu ===== */
        nav {
            background-color: #a61717;
            display: flex;
            justify-content: center;
            gap: 40px;
            padding: 15px 0;
        }

        nav a {
            color: white;
            text-decoration: none;
            font-weight: 600;
            font-size: 1.05em;
            transition: 0.3s;
            position: relative;
        }

        nav a::after {
            content: "";
            position: absolute;
            bottom: -6px;
            left: 0;
            width: 0%;
            height: 2px;
            background-color: #ffc300;
            transition: 0.3s;
        }

        nav a:hover::after {
            width: 100%;
        }

        nav a:hover {
            color: #ffc300;
        }

        /* ===== Produtos ===== */
        .container {
            max-width: 1300px;
            margin: 30px auto;
            padding: 0 20px;
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));
            gap: 30px;
        }

        .produto {
            background-color: white;
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0,0,0,0.1);
            padding: 20px;
            text-align: center;
            transition: 0.3s;
        }

        .produto:hover {
            transform: translateY(-6px);
        }

        .produto img {
            width: 100%;
            height: 180px;
            object-fit: cover;
            border-radius: 10px;
        }

        .produto h2 {
            color: rgb(181, 24, 24);
            font-size: 1.3em;
            margin: 12px 0 5px;
        }

        .produto p {
            color: #333;
            font-size: 1em;
            margin: 8px 0;
        }

        .botao-comprar {
            background-color: rgb(181, 24, 24);
            color: white;
            padding: 12px 24px;
            border: none;
            border-radius: 25px;
            font-size: 1em;
            cursor: pointer;
            margin-top: 10px;
            transition: 0.3s;
        }

        .botao-comprar:hover {
            background-color: rgb(140, 18, 18);
        }

        #mensagem {
            text-align: center;
            margin: 40px auto;
            font-size: 1.2em;
            color: rgb(181, 24, 24);
            font-weight: bold;
        }
    </style>
</head>
<body>

<header>
    <a href="index.php"><img src="assets/imgs/logo.png" class="logo"></a>
        <ul>
            <li><a href="index.php">Inicio</a></li>
            <li><a href="cardapio.php">Cardápio</a></li>
            <li><a href="#">Novidades</a></li>
            <li><a href="#">Contato</a></li>
         </ul>
</header>

<div class="container">
    <div class="produto">
        <img src="https://mcdonalds.com.br/uploads/Big-Mac_678x441_4f7230e25e.jpg" alt="Big Mac">
        <h2>Big Mac</h2>
        <p>R$ 24,90</p>
        <button class="botao-comprar" onclick="comprar('Big Mac', 24.90)">Comprar</button>
    </div>

    <div class="produto">
        <img src="https://mcdonalds.com.br/uploads/McChicken_678x441_2da99df826.jpg" alt="McChicken">
        <h2>McChicken</h2>
        <p>R$ 19,90</p>
        <button class="botao-comprar" onclick="comprar('McChicken', 19.90)">Comprar</button>
    </div>

    <div class="produto">
        <img src="https://mcdonalds.com.br/uploads/Cheeseburger-Duplo_678x441_227d2051b9.jpg" alt="Cheeseburger Duplo">
        <h2>Cheeseburger Duplo</h2>
        <p>R$ 22,90</p>
        <button class="botao-comprar" onclick="comprar('Cheeseburger Duplo', 22.90)">Comprar</button>
    </div>

    <div class="produto">
        <img src="https://mcdonalds.com.br/uploads/Quarterao_678x441_89c2df02f1.jpg" alt="Quarterão com Queijo">
        <h2>Quarterão com Queijo</h2>
        <p>R$ 25,90</p>
        <button class="botao-comprar" onclick="comprar('Quarterão com Queijo', 25.90)">Comprar</button>
    </div>

    <div class="produto">
        <img src="https://mcdonalds.com.br/uploads/McNifico-Bacon_678x441_06a7c3de55.jpg" alt="McNífico Bacon">
        <h2>McNífico Bacon</h2>
        <p>R$ 27,90</p>
        <button class="botao-comprar" onclick="comprar('McNífico Bacon', 27.90)">Comprar</button>
    </div>

    <div class="produto">
        <img src="https://mcdonalds.com.br/uploads/McFish_678x441_3e4052e69a.jpg" alt="McFish">
        <h2>McFish</h2>
        <p>R$ 21,90</p>
        <button class="botao-comprar" onclick="comprar('McFish', 21.90)">Comprar</button>
    </div>

    <div class="produto">
        <img src="https://mcdonalds.com.br/uploads/Triplo-Cheddar-McMelt_678x441_6d3f37ee7a.jpg" alt="Triplo Cheddar McMelt">
        <h2>Triplo Cheddar McMelt</h2>
        <p>R$ 29,90</p>
        <button class="botao-comprar" onclick="comprar('Triplo Cheddar McMelt', 29.90)">Comprar</button>
    </div>

    <div class="produto">
        <img src="https://mcdonalds.com.br/uploads/McCrispy-Chicken-Deluxe_678x441_30e08e9b8c.jpg" alt="McCrispy Chicken Deluxe">
        <h2>McCrispy Chicken Deluxe</h2>
        <p>R$ 26,90</p>
        <button class="botao-comprar" onclick="comprar('McCrispy Chicken Deluxe', 26.90)">Comprar</button>
    </div>

    <div class="produto">
        <img src="https://mcdonalds.com.br/uploads/McVeggie_678x441_7c6c9dd4a8.jpg" alt="McVeggie">
        <h2>McVeggie</h2>
        <p>R$ 23,90</p>
        <button class="botao-comprar" onclick="comprar('McVeggie', 23.90)">Comprar</button>
    </div>

    <div class="produto">
        <img src="https://mcdonalds.com.br/uploads/Big-Tasty_678x441_5a9fd52e1c.jpg" alt="Big Tasty">
        <h2>Big Tasty</h2>
        <p>R$ 28,90</p>
        <button class="botao-comprar" onclick="comprar('Big Tasty', 28.90)">Comprar</button>
    </div>

    <div class="produto">
        <img src="https://mcdonalds.com.br/uploads/McBrasil_678x441_52e14a9333.jpg" alt="McBrasil">
        <h2>McBrasil</h2>
        <p>R$ 27,50</p>
        <button class="botao-comprar" onclick="comprar('McBrasil', 27.50)">Comprar</button>
    </div>

    <div class="produto">
        <img src="https://mcdonalds.com.br/uploads/McBacon_678x441_3b4e2dfb4c.jpg" alt="McBacon">
        <h2>McBacon</h2>
        <p>R$ 25,90</p>
        <button class="botao-comprar" onclick="comprar('McBacon', 25.90)">Comprar</button>
    </div>
</div>

<div id="mensagem"></div>